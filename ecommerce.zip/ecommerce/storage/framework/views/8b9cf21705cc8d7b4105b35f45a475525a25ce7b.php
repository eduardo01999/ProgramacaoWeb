<?php $__env->startSection('titulo'); ?>
    Esta é uma página de exemplo!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <h3>Este é um exemplo de conteúdo</h3>
    <div class="alert alert-danger">Conteúdo do Alert!</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookair/Documents/ecommerce/resources/views/exemplo.blade.php ENDPATH**/ ?>