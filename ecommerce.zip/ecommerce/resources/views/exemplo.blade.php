@extends('layout')

@section('titulo')
    Esta é uma página de exemplo!
@endsection

@section('conteudo')
    <h3>Este é um exemplo de conteúdo</h3>
    <div class="alert alert-danger">Conteúdo do Alert!</div>
@endsection
